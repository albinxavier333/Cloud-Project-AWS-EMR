package com.example.blockbuster;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;

public class PopulateOnUi extends ActionBarActivity {

	ListView listview;
	TextView tv1;
	String data = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_populate_on_ui);
		String[] values = new String[]{"data1","data2","data3","data4", "data5"};
		String data = null;
		//////////////////////////////////////////////////////////
		String driverName = "com.amazon.hive.jdbc3.HS2Driver";
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//      System.exit(1);
		}
		try {
			Connection con = DriverManager.getConnection("jdbc:hive2://54.171.101.25:10000/default", "", "");
			Statement stmt = con.createStatement();
			String tableName = "msd";
			// show tables
			String sql = "show tables '" + tableName + "'";
			//System.out.println("Running: " + sql);
			ResultSet res = stmt.executeQuery(sql);
			if (res.next()) {
				//  System.out.println(res.getString(1));
				data = res.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		//////////////////////////////////////////////////////////////////
		tv1 = (TextView)findViewById(R.id.textView1);
		tv1.setText(data);
		//listview = (ListView)findViewById(R.id.listView1);

		//	ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
		//				android.R.layout.simple_list_item_1,android.R.id.text1,data);
		//		listview.setAdapter(adapter);
	}
}
